import { c as defineEventHandler, r as requireRole, e as createError } from '../../_/nitro.mjs';
import { g as getDB } from '../../_/index.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const index_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
  requireRole(event, "admin");
  const db = await getDB();
  try {
    const [usersCount] = await db.execute(
      "SELECT COUNT(*) as total FROM users"
    );
    const totalUsers = ((_a = usersCount[0]) == null ? void 0 : _a.total) || 0;
    const [productsCount] = await db.execute(
      "SELECT COUNT(*) as total FROM products"
    );
    const totalProducts = ((_b = productsCount[0]) == null ? void 0 : _b.total) || 0;
    const [categoriesCount] = await db.execute(
      "SELECT COUNT(*) as total FROM categories"
    );
    const totalCategories = ((_c = categoriesCount[0]) == null ? void 0 : _c.total) || 0;
    const [attributesCount] = await db.execute(
      "SELECT COUNT(*) as total FROM attributes"
    );
    const totalAttributes = ((_d = attributesCount[0]) == null ? void 0 : _d.total) || 0;
    const [productsInStock] = await db.execute(
      "SELECT COUNT(*) as total FROM products WHERE stock > 0"
    );
    const productsAvailable = ((_e = productsInStock[0]) == null ? void 0 : _e.total) || 0;
    const [productsOutOfStock] = await db.execute(
      "SELECT COUNT(*) as total FROM products WHERE stock = 0"
    );
    const productsUnavailable = ((_f = productsOutOfStock[0]) == null ? void 0 : _f.total) || 0;
    const [activeProducts] = await db.execute(
      "SELECT COUNT(*) as total FROM products WHERE status = 1"
    );
    const activeProductsCount = ((_g = activeProducts[0]) == null ? void 0 : _g.total) || 0;
    const [activeCategories] = await db.execute(
      "SELECT COUNT(*) as total FROM categories WHERE status = 1"
    );
    const activeCategoriesCount = ((_h = activeCategories[0]) == null ? void 0 : _h.total) || 0;
    const [adminUsers] = await db.execute(
      "SELECT COUNT(*) as total FROM users WHERE role = 'admin'"
    );
    const adminUsersCount = ((_i = adminUsers[0]) == null ? void 0 : _i.total) || 0;
    const [regularUsers] = await db.execute(
      "SELECT COUNT(*) as total FROM users WHERE role = 'user'"
    );
    const regularUsersCount = ((_j = regularUsers[0]) == null ? void 0 : _j.total) || 0;
    const [recentProducts] = await db.execute(
      "SELECT COUNT(*) as total FROM products WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
    );
    const recentProductsCount = ((_k = recentProducts[0]) == null ? void 0 : _k.total) || 0;
    const [recentUsers] = await db.execute(
      "SELECT COUNT(*) as total FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
    );
    const recentUsersCount = ((_l = recentUsers[0]) == null ? void 0 : _l.total) || 0;
    return {
      success: true,
      data: {
        users: {
          total: totalUsers,
          admins: adminUsersCount,
          regular: regularUsersCount,
          recent: recentUsersCount
        },
        products: {
          total: totalProducts,
          available: productsAvailable,
          unavailable: productsUnavailable,
          active: activeProductsCount,
          recent: recentProductsCount
        },
        categories: {
          total: totalCategories,
          active: activeCategoriesCount
        },
        attributes: {
          total: totalAttributes
        }
      }
    };
  } catch (error) {
    throw createError({
      statusCode: 500,
      statusMessage: "\u062E\u0637\u0627 \u062F\u0631 \u062F\u0631\u06CC\u0627\u0641\u062A \u0622\u0645\u0627\u0631",
      message: error.message
    });
  }
});

export { index_get as default };
//# sourceMappingURL=index.get4.mjs.map
