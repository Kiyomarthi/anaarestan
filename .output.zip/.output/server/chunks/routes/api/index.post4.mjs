import { c as defineEventHandler } from '../../_/nitro.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';

const index_post = defineEventHandler(async (event) => {
  return { test: true };
});

export { index_post as default };
//# sourceMappingURL=index.post4.mjs.map
