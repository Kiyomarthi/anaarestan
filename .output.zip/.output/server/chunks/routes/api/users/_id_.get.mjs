import { c as defineEventHandler, r as requireRole, g as getRouterParam, e as createError, l as userFields } from '../../../_/nitro.mjs';
import { g as getDB } from '../../../_/index.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const _id__get = defineEventHandler(async (event) => {
  requireRole(event, "admin");
  const id = getRouterParam(event, "id");
  if (!id) {
    throw createError({
      statusCode: 400,
      statusMessage: "User ID is required"
    });
  }
  const db = await getDB();
  const [rows] = await db.execute(
    `SELECT ${userFields.join(", ")} FROM users WHERE id = ?`,
    [id]
  );
  if (!rows || rows.length === 0) {
    throw createError({
      statusCode: 404,
      statusMessage: "User not found"
    });
  }
  return {
    success: true,
    data: rows[0]
  };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
