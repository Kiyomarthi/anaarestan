import { c as defineEventHandler, y as requireAuth, l as userFields } from '../../../_/nitro.mjs';
import { g as getDB } from '../../../_/index.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const me_get = defineEventHandler(async (event) => {
  var _a;
  const user = requireAuth(event);
  const db = await getDB();
  const [rows] = await db.execute(
    `SELECT ${userFields.join(", ")}, password FROM users WHERE id = ?`,
    [user == null ? void 0 : user.id]
  );
  const userData = rows[0];
  const hasPassword = !!((_a = rows[0]) == null ? void 0 : _a.password);
  return { success: true, user: { ...userData, hasPassword } };
});

export { me_get as default };
//# sourceMappingURL=me.get.mjs.map
