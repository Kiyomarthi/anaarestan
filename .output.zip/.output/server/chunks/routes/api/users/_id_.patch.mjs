import { c as defineEventHandler, r as requireRole, f as readBody, e as createError, v as validateBody, h as buildUpdateQuery, l as userFields, q as userAdminFields } from '../../../_/nitro.mjs';
import { g as getDB } from '../../../_/index.mjs';
import { v as validate } from '../../../_/index2.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const _id__patch = defineEventHandler(async (event) => {
  var _a;
  requireRole(event, "admin");
  const id = (_a = event.context.params) == null ? void 0 : _a.id;
  const body = await readBody(event);
  if (!id) {
    throw createError({
      statusCode: 400,
      statusMessage: "\u0634\u0646\u0627\u0633\u0647 \u06A9\u0627\u0631\u0628\u0631 \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A"
    });
  }
  validateBody(body, {
    full_name: (v) => validate(v).min(3).max(100).run(),
    phone: (v) => validate(v).phone().run(),
    role: (v) => validate(v).checkMatch(["admin", "user"]).run(),
    password: (v) => validate(v).password().run()
  });
  const query = await buildUpdateQuery(
    "users",
    body,
    "id",
    id,
    userAdminFields
  );
  if (!query) {
    return {
      success: false,
      message: "\u0647\u06CC\u0686 \u0641\u06CC\u0644\u062F \u0645\u0639\u062A\u0628\u0631\u06CC \u0628\u0631\u0627\u06CC \u0628\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06CC \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A"
    };
  }
  const db = await getDB();
  await db.execute(query.sql, query.values);
  const [rows] = await db.execute(
    `SELECT ${userFields.join(", ")} FROM users WHERE id = ?`,
    [id]
  );
  return {
    success: true,
    data: rows[0] || null
  };
});

export { _id__patch as default };
//# sourceMappingURL=_id_.patch.mjs.map
