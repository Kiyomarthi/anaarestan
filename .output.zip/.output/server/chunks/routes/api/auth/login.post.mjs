import { c as defineEventHandler, f as readBody, v as validateBody, l as userFields, e as createError, m as generateAccessToken } from '../../../_/nitro.mjs';
import { g as getDB } from '../../../_/index.mjs';
import { v as validate } from '../../../_/index2.mjs';
import bcrypt from 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const login_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { phone, password } = body;
  validateBody(
    { phone, password },
    {
      phone: (v) => validate(v).required().phone().run(),
      password: (v) => validate(v).required().password().run()
    }
  );
  const db = await getDB();
  const [rows] = await db.execute(
    `SELECT ${userFields.join(", ")}, password FROM users WHERE phone = ?`,
    [phone]
  );
  const userRow = rows[0];
  if (!userRow || !userRow.password) {
    throw createError({
      statusCode: 400,
      statusMessage: "\u0634\u0645\u0627\u0631\u0647 \u062A\u0644\u0641\u0646 \u06CC\u0627 \u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0627\u0634\u062A\u0628\u0627\u0647 \u0627\u0633\u062A"
    });
  }
  const isMatch = await bcrypt.compare(password, userRow.password);
  if (!isMatch) {
    throw createError({
      statusCode: 400,
      statusMessage: "\u0634\u0645\u0627\u0631\u0647 \u062A\u0644\u0641\u0646 \u06CC\u0627 \u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0627\u0634\u062A\u0628\u0627\u0647 \u0627\u0633\u062A"
    });
  }
  const { password: _pw, ...user } = userRow;
  const token = generateAccessToken(user);
  return { success: true, data: { token, user } };
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
