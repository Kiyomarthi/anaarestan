import { c as defineEventHandler, u as useRuntimeConfig, g as getRouterParam, i as useStorage, C as CACHE_KEY, n as buildAbsoluteUrl } from '../../../_/nitro.mjs';
import { g as getDB } from '../../../_/index.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const _id__get = defineEventHandler(async (event) => {
  const {
    public: { siteUrl }
  } = useRuntimeConfig();
  const id = getRouterParam(event, "id");
  if (!id) {
    return {
      success: false,
      message: "\u0634\u0646\u0627\u0633\u0647 \u062F\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A"
    };
  }
  const db = await getDB();
  const redis = useStorage("redis");
  const cacheKey = CACHE_KEY.category(`id:${id}`);
  const addSiteUrl = (category2) => ({
    ...category2,
    image: buildAbsoluteUrl(category2.image, siteUrl),
    children: Array.isArray(category2.children) ? category2.children.map((child) => addSiteUrl(child)) : []
  });
  const cached = await redis.getItem(cacheKey);
  if (cached) {
    return {
      success: true,
      data: addSiteUrl(cached),
      cache: true
    };
  }
  const [rows] = await db.query(
    "SELECT * FROM categories ORDER BY id ASC"
  );
  const map = /* @__PURE__ */ new Map();
  rows == null ? void 0 : rows.forEach((row) => {
    map.set(row.id, { ...row, children: [] });
  });
  map.forEach((cat) => {
    if (cat.parent_id && map.has(cat.parent_id)) {
      map.get(cat.parent_id).children.push(cat);
    }
  });
  const category = map.get(Number(id));
  if (!category) {
    return {
      success: false,
      message: "\u062F\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u0645\u0648\u0631\u062F \u0646\u0638\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F"
    };
  }
  await redis.setItem(cacheKey, category);
  return {
    success: true,
    data: addSiteUrl(category)
  };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
