import { c as defineEventHandler, r as requireRole, f as readBody, v as validateBody, w as buildInsertQuery, q as userAdminFields } from '../../_/nitro.mjs';
import { g as getDB } from '../../_/index.mjs';
import { v as validate } from '../../_/index2.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const index_post = defineEventHandler(async (event) => {
  requireRole(event, "admin");
  const body = await readBody(event);
  const { full_name, phone, role, password } = body;
  validateBody(body, {
    full_name: (v) => validate(v).min(3).max(100).run(),
    phone: (v) => validate(v).required().phone().run(),
    role: (v) => validate(v).required().checkMatch(["admin", "user"]).run(),
    password: (v) => validate(v).password().run()
  });
  const db = await getDB();
  const [existing] = await db.execute("SELECT id FROM users WHERE phone = ?", [
    phone
  ]);
  if (Array.isArray(existing) && existing.length > 0) {
    return {
      success: false,
      message: "User with this phone already exists."
    };
  }
  const query = await buildInsertQuery("users", body, userAdminFields);
  if (!query) {
    return {
      success: false,
      data: {
        message: "\u0647\u06CC\u0686 \u0641\u06CC\u0644\u062F\u06CC \u0628\u0631\u0627\u06CC \u062B\u0628\u062A \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F."
      }
    };
  }
  const [result] = await db.execute(query.sql, query.values);
  return {
    success: true,
    data: result[0]
  };
});

export { index_post as default };
//# sourceMappingURL=index.post5.mjs.map
