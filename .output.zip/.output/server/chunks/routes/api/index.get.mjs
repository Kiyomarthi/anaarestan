import { c as defineEventHandler, i as useStorage, j as getQuery, k as getHeader, C as CACHE_KEY } from '../../_/nitro.mjs';
import { g as getDB } from '../../_/index.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const index_get = defineEventHandler(async (event) => {
  var _a;
  const db = await getDB();
  const redis = useStorage("redis");
  const query = getQuery(event);
  const search = typeof query.search === "string" && query.search.trim().length > 0 ? query.search.trim() : null;
  const page = parseInt(query.page) || 1;
  const limit = parseInt(query.limit) || parseInt(query.perPage) || 10;
  const offset = (page - 1) * limit;
  const cacheKeyHeader = getHeader(event, "cache-key");
  const cacheKey = cacheKeyHeader && !search ? CACHE_KEY.attribute(
    `${cacheKeyHeader}-p${page}-pp${limit}-s${search || "all"}`
  ) : null;
  if (cacheKey) {
    const cached = await redis.getItem(cacheKey);
    if (cached) {
      return {
        success: true,
        ...cached,
        cache: true
      };
    }
  }
  const params = [];
  let whereClause = "1=1";
  if (search) {
    whereClause += " AND name LIKE ?";
    params.push(`%${search}%`);
  }
  const [countRows] = await db.query(
    `SELECT COUNT(*) as total FROM attributes WHERE ${whereClause}`,
    params
  );
  const total = ((_a = countRows == null ? void 0 : countRows[0]) == null ? void 0 : _a.total) || 0;
  const [attributesRows] = await db.query(
    `SELECT * FROM attributes WHERE ${whereClause} ORDER BY id ASC LIMIT ? OFFSET ?`,
    [...params, limit, offset]
  );
  const attributeIds = attributesRows.map((a) => a.id);
  let valuesRows = [];
  if (attributeIds.length) {
    const placeholders = attributeIds.map(() => "?").join(",");
    [valuesRows] = await db.query(
      `SELECT id, attribute_id, value FROM attribute_values WHERE attribute_id IN (${placeholders}) ORDER BY attribute_id ASC, id ASC`,
      attributeIds
    );
  }
  const valuesMap = /* @__PURE__ */ new Map();
  valuesRows == null ? void 0 : valuesRows.forEach((row) => {
    if (!valuesMap.has(row.attribute_id)) {
      valuesMap.set(row.attribute_id, []);
    }
    valuesMap.get(row.attribute_id).push(row);
  });
  const data = (attributesRows == null ? void 0 : attributesRows.map((attr) => ({
    ...attr,
    values: valuesMap.get(attr.id) || []
  }))) || [];
  const response = {
    success: true,
    data,
    meta: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit)
    }
  };
  if (cacheKey) {
    await redis.setItem(cacheKey, response);
  }
  return response;
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
