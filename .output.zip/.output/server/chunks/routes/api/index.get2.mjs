import { c as defineEventHandler, i as useStorage, u as useRuntimeConfig, j as getQuery, k as getHeader, C as CACHE_KEY, n as buildAbsoluteUrl } from '../../_/nitro.mjs';
import { g as getDB } from '../../_/index.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const index_get = defineEventHandler(async (event) => {
  const db = await getDB();
  const redis = useStorage("redis");
  const {
    public: { siteUrl }
  } = useRuntimeConfig();
  const query = getQuery(event);
  const search = typeof query.search === "string" && query.search.trim().length > 0 ? query.search.trim() : null;
  const noPaginate = query.noPaginate === "true" || query.noPaginate === true;
  const page = parseInt(query.page) || 1;
  const limit = parseInt(query.limit) || parseInt(query.perPage) || 10;
  const offset = noPaginate ? 0 : (page - 1) * limit;
  const cacheKeyHeader = getHeader(event, "cache-key");
  const cacheKey = cacheKeyHeader && !search ? CACHE_KEY.category(cacheKeyHeader) : null;
  const addSiteUrl = (category) => ({
    ...category,
    image: buildAbsoluteUrl(category.image, siteUrl),
    children: Array.isArray(category.children) ? category.children.map((child) => addSiteUrl(child)) : []
  });
  const flattenCategories = (items = [], level = 0) => items.flatMap((cat) => {
    var _a;
    const current = { ...cat, level };
    const children = flattenCategories((_a = cat.children) != null ? _a : [], level + 1);
    return [current, ...children];
  });
  if (cacheKey) {
    const cached = await redis.getItem(cacheKey);
    if (cached) {
      const cachedTree = cached.map((cat) => addSiteUrl(cat));
      if (noPaginate) {
        return {
          success: true,
          data: cachedTree,
          meta: {
            total: flattenCategories(cachedTree).length
          },
          cache: true
        };
      }
      const flattened2 = flattenCategories(cachedTree);
      const total2 = flattened2.length;
      const paginatedData2 = flattened2.slice(offset, offset + limit);
      return {
        success: true,
        data: paginatedData2,
        meta: {
          page,
          limit,
          total: total2,
          totalPages: Math.ceil(total2 / limit)
        },
        cache: true
      };
    }
  }
  const params = [];
  let sql = "SELECT * FROM categories";
  if (search) {
    sql += " WHERE name LIKE ? OR slug LIKE ? OR code LIKE ?";
    const term = `%${search}%`;
    params.push(term, term, term);
  }
  sql += " ORDER BY id ASC";
  const [rows] = await db.query(sql, params);
  const map = /* @__PURE__ */ new Map();
  rows == null ? void 0 : rows.forEach((row) => {
    map.set(row.id, { ...row, children: [] });
  });
  const tree = [];
  map.forEach((cat) => {
    if (cat.parent_id && map.has(cat.parent_id)) {
      map.get(cat.parent_id).children.push(cat);
    } else {
      tree.push(cat);
    }
  });
  const responseData = tree.map((cat) => addSiteUrl(cat));
  const flattened = flattenCategories(tree).map((cat) => addSiteUrl(cat));
  const total = flattened.length;
  if (noPaginate) {
    if (cacheKey) {
      await redis.setItem(cacheKey, tree);
    }
    return {
      success: true,
      data: responseData,
      meta: {
        total
      }
    };
  }
  const paginatedData = responseData.slice(offset, offset + limit);
  if (cacheKey) {
    await redis.setItem(cacheKey, tree);
  }
  return {
    success: true,
    data: paginatedData,
    meta: {
      page,
      limit,
      total: responseData.length,
      // Total parent categories
      totalPages: Math.ceil(responseData.length / limit)
    }
  };
});

export { index_get as default };
//# sourceMappingURL=index.get2.mjs.map
