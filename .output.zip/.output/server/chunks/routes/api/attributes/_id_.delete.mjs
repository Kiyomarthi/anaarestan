import { c as defineEventHandler, r as requireRole, g as getRouterParam, e as createError } from '../../../_/nitro.mjs';
import { g as getDB } from '../../../_/index.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const _id__delete = defineEventHandler(async (event) => {
  requireRole(event, "admin");
  const id = getRouterParam(event, "id");
  if (!id) {
    throw createError({
      statusCode: 400,
      statusMessage: "\u0634\u0646\u0627\u0633\u0647 \u0648\u06CC\u0698\u06AF\u06CC \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A"
    });
  }
  const db = await getDB();
  const [rows] = await db.query("SELECT * FROM attributes WHERE id = ?", [
    id
  ]);
  const attribute = rows[0] || null;
  if (!attribute) {
    return {
      success: false,
      message: "\u0648\u06CC\u0698\u06AF\u06CC \u0645\u0648\u0631\u062F \u0646\u0638\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F"
    };
  }
  const [valuesRows] = await db.query(
    "SELECT id, attribute_id, value FROM attribute_values WHERE attribute_id = ?",
    [id]
  );
  await db.query("DELETE FROM attribute_values WHERE attribute_id = ?", [id]);
  await db.query("DELETE FROM attributes WHERE id = ?", [id]);
  return {
    success: true,
    message: "\u0648\u06CC\u0698\u06AF\u06CC \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062D\u0630\u0641 \u0634\u062F",
    data: {
      ...attribute,
      values: valuesRows || []
    }
  };
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
