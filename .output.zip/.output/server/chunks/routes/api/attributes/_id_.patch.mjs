import { c as defineEventHandler, r as requireRole, g as getRouterParam, e as createError, f as readBody, v as validateBody, h as buildUpdateQuery } from '../../../_/nitro.mjs';
import { g as getDB } from '../../../_/index.mjs';
import { v as validate } from '../../../_/index2.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const _id__patch = defineEventHandler(async (event) => {
  requireRole(event, "admin");
  const id = getRouterParam(event, "id");
  if (!id) {
    throw createError({
      statusCode: 400,
      statusMessage: "\u0634\u0646\u0627\u0633\u0647 \u0648\u06CC\u0698\u06AF\u06CC \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A"
    });
  }
  const body = await readBody(event);
  const { name, type, values } = body;
  validateBody(body, {
    name: (v) => validate(v).min(2).max(50).run(),
    type: (v) => validate(v).checkMatch(["product", "variant"]).run(),
    values: (v) => validate(v).array().run()
  });
  const db = await getDB();
  const [existingRows] = await db.query(
    "SELECT * FROM attributes WHERE id = ?",
    [id]
  );
  if (!existingRows.length) {
    throw createError({
      statusCode: 404,
      statusMessage: "\u0648\u06CC\u0698\u06AF\u06CC \u0645\u0648\u0631\u062F \u0646\u0638\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F"
    });
  }
  const updateData = {};
  if (name !== void 0) {
    updateData.name = name;
  }
  if (type !== void 0) {
    updateData.type = type;
  }
  if (Object.keys(updateData).length > 0) {
    const updateQuery = await buildUpdateQuery(
      "attributes",
      updateData,
      "id",
      id,
      ["name", "type"]
    );
    if (updateQuery) {
      const sql = updateQuery.sql.replace("SET", "SET updated_at = NOW(),");
      await db.query(sql, updateQuery.values);
    }
  }
  if (values !== void 0 && Array.isArray(values)) {
    await db.query("DELETE FROM attribute_values WHERE attribute_id = ?", [id]);
    for (const val of values) {
      await db.query(
        `INSERT INTO attribute_values (attribute_id, value, created_at, updated_at)
         VALUES (?, ?, NOW(), NOW())`,
        [id, val]
      );
    }
  }
  const [updatedRows] = await db.query(
    "SELECT * FROM attributes WHERE id = ?",
    [id]
  );
  const [valuesRows] = await db.query(
    "SELECT id, attribute_id, value FROM attribute_values WHERE attribute_id = ? ORDER BY id ASC",
    [id]
  );
  const updatedAttribute = {
    ...updatedRows[0],
    values: valuesRows || []
  };
  return {
    success: true,
    message: "\u0648\u06CC\u0698\u06AF\u06CC \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0628\u0647\u200C\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06CC \u0634\u062F",
    data: updatedAttribute
  };
});

export { _id__patch as default };
//# sourceMappingURL=_id_.patch.mjs.map
