import { c as defineEventHandler, r as requireRole, j as getQuery, l as userFields } from '../../_/nitro.mjs';
import { g as getDB } from '../../_/index.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const index_get = defineEventHandler(async (event) => {
  var _a;
  requireRole(event, "admin");
  const query = getQuery(event);
  const page = parseInt(query.page) || 1;
  const limit = parseInt(query.limit) || parseInt(query.perPage) || 10;
  const offset = (page - 1) * limit;
  const search = query.search;
  const db = await getDB();
  let whereClause = "1=1";
  const params = [];
  if (search) {
    whereClause += " AND (full_name LIKE ? OR phone LIKE ?)";
    params.push(`%${search}%`, `%${search}%`);
  }
  const selectSql = `SELECT ${userFields.join(
    ", "
  )} FROM users WHERE ${whereClause} ORDER BY created_at DESC LIMIT ${limit} OFFSET ${offset}`;
  const [rows] = await db.execute(selectSql, params);
  const [countRows] = await db.execute(
    `SELECT COUNT(*) as total FROM users WHERE ${whereClause}`,
    params
  );
  const total = ((_a = countRows[0]) == null ? void 0 : _a.total) || 0;
  return {
    success: true,
    data: rows,
    meta: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit)
    }
  };
});

export { index_get as default };
//# sourceMappingURL=index.get5.mjs.map
