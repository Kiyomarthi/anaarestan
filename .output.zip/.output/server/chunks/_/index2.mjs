function validate(value) {
  const rules = [];
  return {
    required(message = "\u0627\u06CC\u0646 \u0641\u06CC\u0644\u062F \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A") {
      rules.push(
        (v) => v === null || v === void 0 || v === "" ? message : true
      );
      return this;
    },
    min(min, message = `\u062D\u062F\u0627\u0642\u0644 ${min} \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631`) {
      rules.push((v) => {
        if (!v) return true;
        return String(v).length < min ? message : true;
      });
      return this;
    },
    max(max, message = `\u062D\u062F\u0627\u06A9\u062B\u0631 ${max} \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631`) {
      rules.push((v) => {
        if (!v) return true;
        return String(v).length > max ? message : true;
      });
      return this;
    },
    equal(length, message = `\u0645\u0642\u062F\u0627\u0631 \u0648\u0627\u0631\u062F \u0634\u062F\u0647 \u0628\u0627\u06CC\u062F ${length} \u0631\u0642\u0645 \u0628\u0627\u0634\u062F`) {
      rules.push((v) => {
        if (!v) return true;
        return String(v).length != length ? message : true;
      });
      return this;
    },
    email(message = "\u0627\u06CC\u0645\u06CC\u0644 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A") {
      const regex = /\S+@\S+\.\S+/;
      rules.push((v) => {
        if (!v) return true;
        return !regex.test(String(v)) ? message : true;
      });
      return this;
    },
    phone(message = "\u0634\u0645\u0627\u0631\u0647 \u062A\u0644\u0641\u0646 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A") {
      const regex = /^(09|98)\d{9}$/;
      rules.push((v) => {
        if (!v) return true;
        return !regex.test(String(v)) ? message : true;
      });
      return this;
    },
    checkMatch(allowed, message = "\u0646\u0642\u0634 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A") {
      rules.push((v) => {
        if (!v) return true;
        if (typeof allowed === "string") {
          return v === allowed ? true : message;
        } else if (Array.isArray(allowed)) {
          return allowed.includes(v) ? true : message;
        }
        return message;
      });
      return this;
    },
    password(messageMin = "\u067E\u0633\u0648\u0631\u062F \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 \u06F6 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F", messageMax = "\u067E\u0633\u0648\u0631\u062F \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u06A9\u062B\u0631 \u06F5\u06F0 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F") {
      rules.push((v) => {
        if (!v) return true;
        const str = String(v);
        if (str.length < 6) return messageMin;
        if (str.length > 50) return messageMax;
        return true;
      });
      return this;
    },
    slug(message = "\u0627\u0633\u0644\u0627\u06AF \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A. \u0641\u0642\u0637 \u062D\u0631\u0648\u0641 \u0627\u0646\u06AF\u0644\u06CC\u0633\u06CC\u060C \u0639\u062F\u062F \u0648 \u062E\u0637 \u062A\u06CC\u0631\u0647 \u0645\u062C\u0627\u0632 \u0627\u0633\u062A") {
      const regex = /^[a-zA-Z0-9]+(?:-[a-zA-Z0-9]+)*$/;
      rules.push((v) => {
        if (!v) return true;
        const str = String(v).trim();
        return regex.test(str) ? true : message;
      });
      return this;
    },
    array(message = "\u0645\u0642\u0627\u062F\u06CC\u0631 \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A \u0648 \u0628\u0627\u06CC\u062F \u0622\u0631\u0627\u06CC\u0647\u200C\u0627\u06CC \u063A\u06CC\u0631 \u062E\u0627\u0644\u06CC \u0628\u0627\u0634\u062F") {
      rules.push((v) => {
        if (!v) return message;
        if (!Array.isArray(v) || v.length === 0) return message;
        return true;
      });
      return this;
    },
    run() {
      for (const rule of rules) {
        const result = rule(value);
        if (result !== true) return result;
      }
      return true;
    },
    pushError(fieldName, errors) {
      for (const rule of rules) {
        const result = rule(value);
        if (result !== true) {
          errors.push({ name: fieldName, message: result });
          return false;
        }
      }
      return true;
    }
  };
}

export { validate as v };
//# sourceMappingURL=index2.mjs.map
