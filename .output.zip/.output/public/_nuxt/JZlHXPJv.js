import{ah as l,ai as s}from"./D_sJxZDy.js";function t(i,r){return l(i)?!1:Array.isArray(i)?i.some(a=>s(a,r)):s(i,r)}export{t as i};
