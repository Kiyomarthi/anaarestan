import{d as e,a as n,o}from"./D_sJxZDy.js";const s=e({__name:"inbox",setup(t){return(a,r)=>(o(),n("div",null,"inbox"))}});export{s as default};
