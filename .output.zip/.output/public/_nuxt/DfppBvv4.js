import{u as t}from"./DozL2B9o.js";import{b2 as o,b3 as a}from"./D_sJxZDy.js";const s=o(()=>{const{mdAndDown:e}=t();if(!e.value)return a("/")});export{s as default};
