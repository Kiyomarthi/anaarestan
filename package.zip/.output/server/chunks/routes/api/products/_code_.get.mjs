import { c as defineEventHandler, u as useRuntimeConfig, g as getRouterParam, e as createError, n as buildAbsoluteUrl } from '../../../_/nitro.mjs';
import { g as getDB } from '../../../_/index.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const _code__get = defineEventHandler(async (event) => {
  const {
    public: { siteUrl }
  } = useRuntimeConfig();
  const code = getRouterParam(event, "code");
  if (!code) {
    throw createError({
      statusCode: 400,
      statusMessage: "\u06A9\u062F \u0645\u062D\u0635\u0648\u0644 \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A"
    });
  }
  const db = await getDB();
  try {
    const [productRows] = await db.query(
      `SELECT 
         p.*,
         c.id AS category_id_full,
         c.name AS category_name,
         c.slug AS category_slug
       FROM products p
       LEFT JOIN categories c ON c.id = p.category_id
       WHERE p.code = ?`,
      [code]
    );
    if (!productRows || productRows.length === 0) {
      throw createError({
        statusCode: 404,
        statusMessage: "\u0645\u062D\u0635\u0648\u0644 \u0645\u0648\u0631\u062F \u0646\u0638\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F"
      });
    }
    const product = productRows[0];
    const productId = product.id;
    const category = product.category_id_full ? {
      id: product.category_id_full,
      name: product.category_name,
      slug: product.category_slug
    } : null;
    delete product.category_id_full;
    delete product.category_name;
    delete product.category_slug;
    delete product.category_id;
    const [productAttrRows] = await db.query(
      `SELECT 
         pav.attribute_value_id AS id,
         av.attribute_id,
         a.name,
         av.value
       FROM product_attribute_values pav
       JOIN attribute_values av ON av.id = pav.attribute_value_id
       JOIN attributes a ON a.id = av.attribute_id
       WHERE pav.product_id = ?`,
      [productId]
    );
    const [variantRows] = await db.query(
      `SELECT * FROM product_variants WHERE product_id = ? ORDER BY id ASC`,
      [productId]
    );
    const variantsWithAttrs = await Promise.all(
      variantRows.map(async (variant) => {
        const [variantAttrRows] = await db.query(
          `SELECT 
             vav.attribute_value_id AS id,
             av.attribute_id,
             a.name,
             av.value
           FROM variant_attribute_values vav
           JOIN attribute_values av ON av.id = vav.attribute_value_id
           JOIN attributes a ON a.id = av.attribute_id
           WHERE vav.variant_id = ?`,
          [variant.id]
        );
        return {
          ...variant,
          variant_attributes: variantAttrRows.map((row) => ({
            id: row.id,
            attribute_id: row.attribute_id,
            name: row.name,
            value: row.value
          }))
        };
      })
    );
    const [imageRows] = await db.query(
      `SELECT * FROM product_images WHERE product_id = ? ORDER BY position ASC`,
      [productId]
    );
    const mappedGallery = imageRows.map((img) => ({
      ...img,
      url: buildAbsoluteUrl(img.url, siteUrl)
    }));
    return {
      success: true,
      data: {
        ...product,
        category,
        products_attribute: productAttrRows.map((row) => ({
          id: row.id,
          attribute_id: row.attribute_id,
          name: row.name,
          value: row.value
        })),
        variant_attribute: variantsWithAttrs,
        image: buildAbsoluteUrl(product.image, siteUrl),
        gallery: mappedGallery
      }
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: error.message || "\u062E\u0637\u0627 \u062F\u0631 \u062F\u0631\u06CC\u0627\u0641\u062A \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0645\u062D\u0635\u0648\u0644"
    });
  }
});

export { _code__get as default };
//# sourceMappingURL=_code_.get.mjs.map
