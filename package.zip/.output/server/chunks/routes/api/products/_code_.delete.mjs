import { c as defineEventHandler, r as requireRole, g as getRouterParam, e as createError } from '../../../_/nitro.mjs';
import { g as getDB } from '../../../_/index.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const _code__delete = defineEventHandler(async (event) => {
  requireRole(event, "admin");
  const code = getRouterParam(event, "code");
  if (!code) {
    throw createError({
      statusCode: 400,
      statusMessage: "\u06A9\u062F \u0645\u062D\u0635\u0648\u0644 \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A"
    });
  }
  const db = await getDB();
  const connection = await db.getConnection();
  await connection.beginTransaction();
  try {
    const [productRows] = await connection.query(
      `SELECT id FROM products WHERE code = ?`,
      [code]
    );
    if (!productRows || productRows.length === 0) {
      await connection.rollback();
      connection.release();
      throw createError({
        statusCode: 404,
        statusMessage: "\u0645\u062D\u0635\u0648\u0644 \u0645\u0648\u0631\u062F \u0646\u0638\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F"
      });
    }
    const productId = productRows[0].id;
    const [variantRows] = await connection.query(
      `SELECT id FROM product_variants WHERE product_id = ?`,
      [productId]
    );
    const variantIds = variantRows.map((row) => row.id);
    if (variantIds.length > 0) {
      const placeholders = variantIds.map(() => "?").join(",");
      await connection.query(
        `DELETE FROM variant_attribute_values WHERE variant_id IN (${placeholders})`,
        variantIds
      );
    }
    await connection.query(
      `DELETE FROM product_variants WHERE product_id = ?`,
      [productId]
    );
    await connection.query(
      `DELETE FROM product_attribute_values WHERE product_id = ?`,
      [productId]
    );
    await connection.query(`DELETE FROM product_images WHERE product_id = ?`, [
      productId
    ]);
    await connection.query(`DELETE FROM products WHERE id = ?`, [productId]);
    await connection.commit();
    connection.release();
    return {
      success: true,
      message: "\u0645\u062D\u0635\u0648\u0644 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062D\u0630\u0641 \u0634\u062F"
    };
  } catch (error) {
    await connection.rollback();
    connection.release();
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: error.message || "\u062E\u0637\u0627 \u062F\u0631 \u062D\u0630\u0641 \u0645\u062D\u0635\u0648\u0644"
    });
  }
});

export { _code__delete as default };
//# sourceMappingURL=_code_.delete.mjs.map
