import { c as defineEventHandler, x as requireAuth, f as readBody, v as validateBody, r as requireRole, e as createError } from '../../../_/nitro.mjs';
import { g as getDB } from '../../../_/index.mjs';
import bcrypt from 'bcryptjs';
import { v as validate } from '../../../_/index2.mjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const updatePassword_post = defineEventHandler(async (event) => {
  const user = requireAuth(event);
  const body = await readBody(event);
  const oldPassword = body == null ? void 0 : body.oldPassword;
  const newPassword = body == null ? void 0 : body.newPassword;
  const userId = body == null ? void 0 : body.id;
  validateBody(body, {
    id: (v) => validate(v).required().run()
  });
  if (user.id != userId) {
    requireRole(event, "admin");
  }
  const db = await getDB();
  const [rows] = await db.execute("SELECT password FROM users WHERE id = ?", [
    userId
  ]);
  if (rows[0].password) {
    if (!oldPassword || !newPassword)
      throw createError({
        statusCode: 400,
        statusMessage: "Both passwords are required"
      });
  } else {
    if (!newPassword) {
      throw createError({
        statusCode: 400,
        statusMessage: "new password are required"
      });
    }
  }
  if (rows[0].password) {
    const isMatch = await bcrypt.compare(oldPassword, rows[0].password);
    if (!isMatch)
      throw createError({
        statusCode: 400,
        statusMessage: "Old password is incorrect"
      });
    if (await bcrypt.compare(newPassword, rows[0].password)) {
      throw createError({
        statusCode: 400,
        statusMessage: "New password must be different from old password"
      });
    }
  }
  const hash = await bcrypt.hash(newPassword, 10);
  await db.execute("UPDATE users SET password = ? WHERE id = ?", [
    hash,
    userId
  ]);
  return { success: true };
});

export { updatePassword_post as default };
//# sourceMappingURL=update-password.post.mjs.map
