import { c as defineEventHandler, x as requireAuth, f as readBody, e as createError, v as validateBody, h as buildUpdateQuery, y as allowedUserFields, l as userFields } from '../../../_/nitro.mjs';
import { g as getDB } from '../../../_/index.mjs';
import { v as validate } from '../../../_/index2.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const update_post = defineEventHandler(async (event) => {
  const user = requireAuth(event);
  const body = await readBody(event);
  if (!user || !user.id) {
    throw createError({
      statusCode: 401,
      statusMessage: "Unauthorized: user not logged in"
    });
  }
  validateBody(body, {
    full_name: (v) => validate(v).min(3).max(100).run()
  });
  const query = await buildUpdateQuery(
    "users",
    body,
    "id",
    user == null ? void 0 : user.id,
    allowedUserFields
  );
  if (!query) return { success: false, message: "No valid fields to update" };
  const db = await getDB();
  await db.execute(query.sql, query.values);
  const [rows] = await db.execute(
    `SELECT ${userFields.join(", ")} FROM users WHERE id = ?`,
    [user.id]
  );
  return { success: true, data: rows[0] };
});

export { update_post as default };
//# sourceMappingURL=update.post.mjs.map
