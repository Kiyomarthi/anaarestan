import { c as defineEventHandler, f as readBody, v as validateBody, e as createError, l as userFields, m as generateAccessToken } from '../../../_/nitro.mjs';
import { g as getDB } from '../../../_/index.mjs';
import { v as validate } from '../../../_/index2.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const verifyOtp_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { phone, code } = body;
  validateBody(body, {
    phone: (v) => validate(v).required().phone().run(),
    code: (v) => validate(v).required().equal(4).run()
  });
  const db = await getDB();
  const [rows] = await db.execute(
    "SELECT * FROM otp_codes WHERE phone=? AND code=? AND used=0",
    [phone, code]
  );
  const otp = rows[0];
  if (!otp)
    throw createError({
      statusCode: 400,
      statusMessage: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A"
    });
  if (new Date(otp.expires_at) < /* @__PURE__ */ new Date())
    throw createError({
      statusCode: 400,
      statusMessage: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0645\u0646\u0642\u0636\u06CC \u0634\u062F\u0647 \u0627\u0633\u062A"
    });
  await db.execute("UPDATE otp_codes SET used=1 WHERE id=?", [otp.id]);
  const [userRows] = await db.execute("SELECT * FROM users WHERE phone=?", [
    phone
  ]);
  let user = userRows[0];
  if (!user) {
    const [result] = await db.execute("INSERT INTO users (phone) VALUES (?)", [
      phone
    ]);
    const newUserId = result.insertId;
    const [newUserRows] = await db.execute(
      `SELECT ${userFields.join(", ")} FROM users WHERE id=?`,
      [newUserId]
    );
    user = newUserRows[0];
  }
  const token = generateAccessToken(user);
  const data = { token, user };
  return { success: true, data };
});

export { verifyOtp_post as default };
//# sourceMappingURL=verify-otp.post.mjs.map
