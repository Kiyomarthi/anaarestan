import { c as defineEventHandler, f as readBody, v as validateBody } from '../../../_/nitro.mjs';
import { randomInt } from 'crypto';
import { g as getDB } from '../../../_/index.mjs';
import { v as validate } from '../../../_/index2.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const sendOtp_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  validateBody(body, {
    phone: (v) => validate(v).required().phone().run()
  });
  const phone = body.phone;
  const code = String(randomInt(1e3, 9999));
  const expiresAt = new Date(Date.now() + 2 * 60 * 1e3);
  const db = await getDB();
  const [rows] = await db.execute(
    "SELECT code, expires_at FROM otp_codes WHERE phone = ? ORDER BY expires_at DESC LIMIT 1",
    [phone]
  );
  const lastOtp = rows[0];
  if (lastOtp) {
    const now = /* @__PURE__ */ new Date();
    const expiresAt2 = new Date(lastOtp.expires_at);
    if (expiresAt2 > now) {
      const remaining = Math.ceil((expiresAt2.getTime() - now.getTime()) / 1e3);
      const data2 = {
        message: `An OTP is already sent. Try again in ${remaining} seconds.`,
        remaining
      };
      return {
        success: false,
        data: data2
      };
    }
  }
  await db.execute(
    "INSERT INTO otp_codes (phone, code, expires_at) VALUES (?, ?, ?)",
    [phone, code, expiresAt]
  );
  const data = { expiresAt, code };
  return { success: true, data };
});

export { sendOtp_post as default };
//# sourceMappingURL=send-otp.post.mjs.map
