import { c as defineEventHandler, f as readBody, v as validateBody } from '../../_/nitro.mjs';
import { g as getDB } from '../../_/index.mjs';
import { v as validate } from '../../_/index2.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const index_post = defineEventHandler(async (event) => {
  const db = await getDB();
  const body = await readBody(event);
  const { name, type, values } = body;
  validateBody(body, {
    name: (v) => validate(v).required().min(2).max(50).run(),
    type: (v) => validate(v).required().checkMatch(["product", "variant"]).run(),
    values: (v) => validate(v).array().run()
  });
  const [result] = await db.query(
    `INSERT INTO attributes (name, type, created_at, updated_at)
     VALUES (?, ?, NOW(), NOW())`,
    [name, type]
  );
  const attribute_id = result.insertId;
  for (const val of values) {
    await db.query(
      `INSERT INTO attribute_values (attribute_id, value, created_at, updated_at)
       VALUES (?, ?, NOW(), NOW())`,
      [attribute_id, val]
    );
  }
  return {
    success: true,
    message: "Attribute created successfully",
    data: {
      id: attribute_id,
      name,
      type,
      values
    }
  };
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
