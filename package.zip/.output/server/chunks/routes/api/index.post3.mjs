import { c as defineEventHandler, u as useRuntimeConfig, r as requireRole, f as readBody, v as validateBody, e as createError, p as generateCode, n as buildAbsoluteUrl } from '../../_/nitro.mjs';
import { g as getDB } from '../../_/index.mjs';
import { v as validate } from '../../_/index2.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const index_post = defineEventHandler(async (event) => {
  const db = await getDB();
  const {
    public: { siteUrl }
  } = useRuntimeConfig();
  requireRole(event, "admin");
  const body = await readBody(event);
  const {
    category_id,
    title,
    slug,
    short_description,
    description,
    code,
    status = 1,
    variants,
    product_attributes,
    variant_attributes,
    images
  } = body;
  validateBody(body, {
    category_id: (v) => validate(v).required().run(),
    title: (v) => validate(v).required().min(2).max(150).run(),
    slug: (v) => validate(v).required().slug().run(),
    short_description: (v) => validate(v).max(300).run(),
    description: (v) => validate(v).run(),
    code: (v) => validate(v).max(20).run(),
    status: (v) => validate(v).checkMatch([0, 1]).run(),
    variants: (v) => validate(v).required().array().run(),
    images: (v) => validate(v).required().array().run()
  });
  if (!variants || variants.length === 0) {
    throw createError({
      statusCode: 400,
      statusMessage: "\u062D\u062F\u0627\u0642\u0644 \u06CC\u06A9 variant \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A"
    });
  }
  if (!images || images.length === 0) {
    throw createError({
      statusCode: 400,
      statusMessage: "\u062D\u062F\u0627\u0642\u0644 \u06CC\u06A9 \u0639\u06A9\u0633 \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A"
    });
  }
  const mainImage = images.find((img) => img.position === 1);
  if (!mainImage) {
    throw createError({
      statusCode: 400,
      statusMessage: "\u0639\u06A9\u0633 \u0628\u0627 position \u0628\u0631\u0627\u0628\u0631 1 \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A"
    });
  }
  for (const variant of variants) {
    if (variant.price === void 0 || variant.stock === void 0 || variant.sku === void 0) {
      throw createError({
        statusCode: 400,
        statusMessage: "\u0647\u0631 variant \u0628\u0627\u06CC\u062F \u062F\u0627\u0631\u0627\u06CC price\u060C stock \u0648 sku \u0628\u0627\u0634\u062F"
      });
    }
  }
  const connection = await db.getConnection();
  await connection.beginTransaction();
  try {
    let cheapestVariantIndex = -1;
    let cheapestPrice = Infinity;
    let cheapestVariant = null;
    for (let i = 0; i < variants.length; i++) {
      const variant = variants[i];
      const finalPrice = variant.discount_price && variant.discount_price > 0 ? variant.discount_price : variant.price;
      if (finalPrice < cheapestPrice) {
        cheapestPrice = finalPrice;
        cheapestVariantIndex = i;
        cheapestVariant = variant;
      }
    }
    if (!cheapestVariant || cheapestVariantIndex === -1) {
      throw createError({
        statusCode: 400,
        statusMessage: "\u062E\u0637\u0627 \u062F\u0631 \u0645\u062D\u0627\u0633\u0628\u0647 \u0642\u06CC\u0645\u062A"
      });
    }
    const productCode = generateCode();
    const totalStock = variants.reduce((sum, variant) => {
      return sum + (parseInt(variant.stock) || 0);
    }, 0);
    const [productResult] = await connection.query(
      `INSERT INTO products (
        category_id, title, slug, short_description, description,
        price, discount_price, image, code, main_variant_id, status, stock,
        created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
      [
        category_id,
        title,
        slug,
        short_description || null,
        description || null,
        cheapestVariant.price,
        cheapestVariant.discount_price || null,
        mainImage.url,
        productCode,
        null,
        // Will update after variant is created
        status,
        totalStock
      ]
    );
    const productId = productResult.insertId;
    let mainVariantId = null;
    for (let i = 0; i < variants.length; i++) {
      const variant = variants[i];
      const [variantResult] = await connection.query(
        `INSERT INTO product_variants (
          product_id, sku, price, discount_price, stock, status,
          created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())`,
        [
          productId,
          variant.sku,
          variant.price,
          variant.discount_price || null,
          variant.stock,
          variant.status !== void 0 ? variant.status : 1
        ]
      );
      const variantId = variantResult.insertId;
      if (i === cheapestVariantIndex) {
        mainVariantId = variantId;
      }
      if (variant_attributes && variant_attributes[i]) {
        const variantAttrs = variant_attributes[i];
        if (Array.isArray(variantAttrs)) {
          for (const attrValueId of variantAttrs) {
            await connection.query(
              `INSERT INTO variant_attribute_values (
                variant_id, attribute_value_id, created_at, updated_at
              ) VALUES (?, ?, NOW(), NOW())`,
              [variantId, attrValueId]
            );
          }
        }
      }
    }
    if (mainVariantId) {
      await connection.query(
        `UPDATE products SET main_variant_id = ? WHERE id = ?`,
        [mainVariantId, productId]
      );
    }
    if (product_attributes && Array.isArray(product_attributes)) {
      for (const attrValueId of product_attributes) {
        await connection.query(
          `INSERT INTO product_attribute_values (
            product_id, attribute_value_id, created_at, updated_at
          ) VALUES (?, ?, NOW(), NOW())`,
          [productId, attrValueId]
        );
      }
    }
    for (const img of images) {
      await connection.query(
        `INSERT INTO product_images (
          product_id, url, alt_text, position, created_at, updated_at
        ) VALUES (?, ?, ?, ?, NOW(), NOW())`,
        [productId, img.url, img.alt_text || null, img.position || 0]
      );
    }
    await connection.commit();
    const [productRows] = await connection.query(
      `SELECT 
         p.*,
         c.id AS category_id_full,
         c.name AS category_name,
         c.slug AS category_slug
       FROM products p
       LEFT JOIN categories c ON c.id = p.category_id
       WHERE p.id = ?`,
      [productId]
    );
    const product = productRows[0];
    const category = product.category_id_full ? {
      id: product.category_id_full,
      name: product.category_name,
      slug: product.category_slug
    } : null;
    delete product.category_id_full;
    delete product.category_name;
    delete product.category_slug;
    delete product.category_id;
    const [productAttrRows] = await connection.query(
      `SELECT 
         pav.attribute_value_id AS id,
         av.attribute_id,
         a.name,
         av.value
       FROM product_attribute_values pav
       JOIN attribute_values av ON av.id = pav.attribute_value_id
       JOIN attributes a ON a.id = av.attribute_id
       WHERE pav.product_id = ?`,
      [productId]
    );
    const [variantRows] = await connection.query(
      `SELECT * FROM product_variants WHERE product_id = ?`,
      [productId]
    );
    const variantsWithAttrs = await Promise.all(
      variantRows.map(async (variant) => {
        const [variantAttrRows] = await connection.query(
          `SELECT 
             vav.attribute_value_id AS id,
             av.attribute_id,
             a.name,
             av.value
           FROM variant_attribute_values vav
           JOIN attribute_values av ON av.id = vav.attribute_value_id
           JOIN attributes a ON a.id = av.attribute_id
           WHERE vav.variant_id = ?`,
          [variant.id]
        );
        return {
          ...variant,
          variant_attributes: variantAttrRows.map((row) => ({
            id: row.id,
            attribute_id: row.attribute_id,
            name: row.name,
            value: row.value
          }))
        };
      })
    );
    const [imageRows] = await connection.query(
      `SELECT * FROM product_images WHERE product_id = ? ORDER BY position ASC`,
      [productId]
    );
    connection.release();
    const mappedGallery = imageRows.map((img) => ({
      ...img,
      url: buildAbsoluteUrl(img.url, siteUrl)
    }));
    return {
      success: true,
      message: "\u0645\u062D\u0635\u0648\u0644 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0627\u06CC\u062C\u0627\u062F \u0634\u062F",
      data: {
        ...product,
        category,
        products_attribute: productAttrRows.map((row) => ({
          id: row.id,
          attribute_id: row.attribute_id,
          name: row.name,
          value: row.value
        })),
        variant_attribute: variantsWithAttrs,
        image: buildAbsoluteUrl(product.image, siteUrl),
        gallery: mappedGallery
      }
    };
  } catch (error) {
    await connection.rollback();
    connection.release();
    throw createError({
      statusCode: 500,
      statusMessage: error.message || "\u062E\u0637\u0627 \u062F\u0631 \u0627\u06CC\u062C\u0627\u062F \u0645\u062D\u0635\u0648\u0644"
    });
  }
});

export { index_post as default };
//# sourceMappingURL=index.post3.mjs.map
