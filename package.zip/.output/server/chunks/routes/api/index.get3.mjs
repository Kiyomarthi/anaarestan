import { c as defineEventHandler, u as useRuntimeConfig, j as getQuery, n as buildAbsoluteUrl } from '../../_/nitro.mjs';
import { g as getDB } from '../../_/index.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const index_get = defineEventHandler(async (event) => {
  var _a;
  const db = await getDB();
  const {
    public: { siteUrl }
  } = useRuntimeConfig();
  const query = getQuery(event);
  const noPaginate = query.noPaginate === "true" || query.noPaginate === true;
  const page = parseInt(query.page) || 1;
  const limit = parseInt(query.limit) || parseInt(query.per) || 20;
  const offset = noPaginate ? 0 : (page - 1) * limit;
  const search = query.search ? String(query.search).trim() : null;
  const stockStatus = query.stock_status;
  const categoryId = query.category_id ? parseInt(query.category_id) : null;
  const minPrice = query.min_price ? parseFloat(query.min_price) : null;
  const maxPrice = query.max_price ? parseFloat(query.max_price) : null;
  const sort = query.sort;
  let whereClause = "1=1";
  const params = [];
  if (categoryId !== null && !isNaN(categoryId)) {
    whereClause += " AND category_id = ?";
    params.push(categoryId);
  }
  if (stockStatus === "available") {
    whereClause += " AND stock > 0";
  } else if (stockStatus === "unavailable") {
    whereClause += " AND stock = 0";
  }
  if (minPrice !== null && !isNaN(minPrice)) {
    whereClause += " AND COALESCE(discount_price, price) >= ?";
    params.push(minPrice);
  }
  if (maxPrice !== null && !isNaN(maxPrice)) {
    whereClause += " AND COALESCE(discount_price, price) <= ?";
    params.push(maxPrice);
  }
  if (search) {
    whereClause += " AND title LIKE ?";
    params.push(`%${search}%`);
  }
  let orderBy = "ORDER BY created_at DESC";
  switch (sort) {
    case "cheapest":
      orderBy = "ORDER BY COALESCE(discount_price, price) ASC";
      break;
    case "most-expensive":
      orderBy = "ORDER BY COALESCE(discount_price, price) DESC";
      break;
    case "newest":
      orderBy = "ORDER BY created_at DESC";
      break;
    case "best-selling":
      orderBy = "ORDER BY stock DESC, created_at DESC";
      break;
    default:
      orderBy = "ORDER BY created_at DESC";
  }
  const selectFields = [
    "id",
    "title",
    "slug",
    "short_description",
    "price",
    "discount_price",
    "image",
    "code",
    "stock",
    "status",
    "category_id",
    "created_at",
    "updated_at"
  ].join(", ");
  let selectSql = `SELECT ${selectFields} FROM products WHERE ${whereClause} ${orderBy}`;
  if (!noPaginate) {
    selectSql += ` LIMIT ${limit} OFFSET ${offset}`;
  }
  const [rows] = await db.query(selectSql, params);
  let total = 0;
  let totalPages = 0;
  if (!noPaginate) {
    const [countRows] = await db.query(
      `SELECT COUNT(*) as total FROM products WHERE ${whereClause}`,
      params
    );
    total = ((_a = countRows[0]) == null ? void 0 : _a.total) || 0;
    totalPages = Math.ceil(total / limit);
  } else {
    total = (rows == null ? void 0 : rows.length) || 0;
  }
  const dataWithAbsoluteImage = (rows || []).map((row) => ({
    ...row,
    image: buildAbsoluteUrl(row.image, siteUrl)
  }));
  const response = {
    success: true,
    data: dataWithAbsoluteImage
  };
  if (!noPaginate) {
    response.meta = {
      page,
      limit,
      total,
      totalPages
    };
  } else {
    response.meta = {
      total
    };
  }
  return response;
});

export { index_get as default };
//# sourceMappingURL=index.get3.mjs.map
