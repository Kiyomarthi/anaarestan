import { c as defineEventHandler, u as useRuntimeConfig, r as requireRole, f as readBody, v as validateBody, p as generateCode, n as buildAbsoluteUrl } from '../../_/nitro.mjs';
import { g as getDB } from '../../_/index.mjs';
import { v as validate } from '../../_/index2.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const index_post = defineEventHandler(async (event) => {
  const db = await getDB();
  const {
    public: { siteUrl }
  } = useRuntimeConfig();
  requireRole(event, "admin");
  const body = await readBody(event);
  const { name, parent_id, status = 1, image, slug } = body;
  validateBody(body, {
    name: (v) => validate(v).required().min(2).max(50).run(),
    image: (v) => validate(v).required().max(100).run(),
    status: (v) => validate(v).checkMatch([0, 1]).run(),
    slug: (v) => validate(v).required().slug().run()
  });
  const code = generateCode();
  const [insertResult] = await db.query(
    "INSERT INTO categories (name, slug, parent_id, status, image, code) VALUES (?, ?, ?, ?, ?, ?)",
    [name, slug, parent_id || null, status, image || null, code]
  );
  const [newCategoryRows] = await db.query(
    "SELECT * FROM categories WHERE id = ?",
    [insertResult.insertId]
  );
  const newCategory = newCategoryRows[0];
  return {
    success: true,
    message: "Category created successfully",
    data: {
      ...newCategory,
      image: buildAbsoluteUrl(newCategory.image, siteUrl)
    }
  };
});

export { index_post as default };
//# sourceMappingURL=index.post2.mjs.map
