import { c as defineEventHandler, r as requireRole, g as getRouterParam, e as createError } from '../../../_/nitro.mjs';
import { g as getDB } from '../../../_/index.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const _id__delete = defineEventHandler(async (event) => {
  requireRole(event, "admin");
  const id = getRouterParam(event, "id");
  if (!id) {
    throw createError({
      statusCode: 400,
      statusMessage: "\u0634\u0646\u0627\u0633\u0647 \u062F\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A"
    });
  }
  const db = await getDB();
  const [rows] = await db.query("SELECT * FROM categories WHERE id = ?", [
    id
  ]);
  const category = rows[0] || null;
  if (!category) {
    return {
      success: false,
      message: "\u062F\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u0645\u0648\u0631\u062F \u0646\u0638\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F"
    };
  }
  const [childRows] = await db.query(
    "SELECT id FROM categories WHERE parent_id = ? LIMIT 1",
    [id]
  );
  if (childRows.length) {
    return {
      success: false,
      message: "\u0627\u0628\u062A\u062F\u0627 \u0632\u06CC\u0631 \u062F\u0633\u062A\u0647\u200C\u0647\u0627\u06CC \u0627\u06CC\u0646 \u062F\u0633\u062A\u0647 \u0631\u0627 \u062D\u0630\u0641 \u06CC\u0627 \u0645\u0646\u062A\u0642\u0644 \u06A9\u0646\u06CC\u062F"
    };
  }
  await db.query("DELETE FROM categories WHERE id = ?", [id]);
  return {
    success: true,
    data: category
  };
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
