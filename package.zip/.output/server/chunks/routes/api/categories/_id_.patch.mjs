import { c as defineEventHandler, r as requireRole, g as getRouterParam, u as useRuntimeConfig, e as createError, f as readBody, v as validateBody, o as createSlug, h as buildUpdateQuery, n as buildAbsoluteUrl } from '../../../_/nitro.mjs';
import { g as getDB } from '../../../_/index.mjs';
import { v as validate } from '../../../_/index2.mjs';
import 'bcryptjs';
import 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'ioredis';
import 'node:path';
import 'mysql2/promise';

const _id__patch = defineEventHandler(async (event) => {
  requireRole(event, "admin");
  const id = getRouterParam(event, "id");
  const {
    public: { siteUrl }
  } = useRuntimeConfig();
  if (!id) {
    throw createError({
      statusCode: 400,
      statusMessage: "Category ID is required"
    });
  }
  const body = await readBody(event);
  const { name, parent_id, status, image } = body;
  validateBody(body, {
    name: (v) => validate(v).required().min(2).max(50).run(),
    image: (v) => validate(v).required().max(100).run(),
    status: (v) => validate(v).checkMatch([0, 1]).run()
  });
  const db = await getDB();
  const [existingRows] = await db.query(
    "SELECT id FROM categories WHERE id = ?",
    [id]
  );
  if (!existingRows.length) {
    throw createError({
      statusCode: 404,
      statusMessage: "Category not found"
    });
  }
  const updateData = {};
  if (name) {
    updateData.name = name;
    let slug = createSlug(name);
    const [slugExists] = await db.query(
      "SELECT id FROM categories WHERE slug = ? AND id != ?",
      [slug, id]
    );
    if (slugExists.length) {
      slug = `${slug}-${Date.now()}`;
    }
    updateData.slug = slug;
  }
  if (parent_id !== void 0) {
    updateData.parent_id = parent_id || null;
  }
  if (status !== void 0) {
    updateData.status = status;
  }
  if (image !== void 0) {
    updateData.image = image || null;
  }
  if (Object.keys(updateData).length === 0) {
    throw createError({
      statusCode: 400,
      statusMessage: "No fields to update"
    });
  }
  const updateQuery = await buildUpdateQuery(
    "categories",
    updateData,
    "id",
    id,
    ["name", "slug", "parent_id", "status", "image"]
  );
  if (!updateQuery) {
    throw createError({
      statusCode: 400,
      statusMessage: "No valid fields to update"
    });
  }
  await db.query(updateQuery.sql, updateQuery.values);
  const [updatedRows] = await db.query(
    "SELECT * FROM categories WHERE id = ?",
    [id]
  );
  const updatedCategory = updatedRows[0];
  return {
    success: true,
    message: "Category updated successfully",
    data: {
      ...updatedCategory,
      image: buildAbsoluteUrl(updatedCategory.image, siteUrl)
    }
  };
});

export { _id__patch as default };
//# sourceMappingURL=_id_.patch.mjs.map
