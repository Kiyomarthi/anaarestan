export default defineAppConfig({
  ui: {
    theme: {
      default: "light",
    },

    colors: {
      primary: "primary",
    },
  },
});
