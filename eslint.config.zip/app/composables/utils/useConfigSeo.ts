import { computed } from "vue";
import type { PageResponse } from "~~/shared/types/api";

export const useConfigSeo = () => {
  const siteConfig = computed(() => useRuntimeConfig());
  const route = useRoute();

  const buildMeta = (seo: PageResponse) => {
    useSeoMeta({
      title:
        seo?.page?.seo_title || `انارستان | فروشگاه آنلاین خرید کالاهای متنوع`,
      titleTemplate: (title) => {
        if (route.path === "/") {
          return seo?.page?.seo_title;
        } else {
          return `${title} | انارستان`;
        }
      },
      description: seo?.page?.seo_description || siteConfig.value?.public?.desc,
      robots: {
        index: !!seo?.page?.seo_index, // TODO: change to true in production
        follow: !!seo?.page?.seo_index, // TODO: change to true in production
        noimageindex: false,
        nosnippet: false,
        maxSnippet: -1,
        maxImagePreview: "large",
        maxVideoPreview: -1,
      },
      publisher: siteConfig.value?.public?.siteNameFa,
      charset: "utf-8",
      applicationName: siteConfig.value.public?.siteNameFa,
      mobileWebAppCapable: "yes",
      appleMobileWebAppCapable: "yes",
      ogSiteName: siteConfig.value.public.siteNameFa,
      appleMobileWebAppTitle: siteConfig.value.public.siteNameFa,
      ogImage:
        seo?.page?.seo_image ||
        `${siteConfig.value.public.siteUrl}/images/logo-og.png`,
      ogImageAlt: seo?.page?.title || "فروشگاه آنلاین خرید کالاهای متنوع",
      ogImageHeight: "630",
      ogImageWidth: "1200",
      themeColor: "#e63a33",
      referrer: "strict-origin-when-cross-origin",
      ogImageType: "image/png",
      ogLocale: "fa_IR",
      ogTitle: seo?.page?.title || "فروشگاه آنلاین خرید کالاهای متنوع",
      ogDescription:
        seo?.page?.seo_description || siteConfig.value?.public?.desc,
      ogUrl: `${siteConfig.value.public.siteUrl}/${
        seo?.page?.seo_canonical ?? ""
      }`,
      ogType: seo?.page?.seo_og_type || "website",
      twitterTitle: seo?.page?.title || "فروشگاه آنلاین خرید کالاهای متنوع",
      twitterDescription:
        seo?.page?.seo_description || siteConfig.value?.public?.desc,
      twitterImageAlt: seo?.page?.title || "فروشگاه آنلاین خرید کالاهای متنوع",
      twitterImage:
        seo?.page?.seo_image ||
        `${siteConfig.value.public.siteUrl}/images/logo-og.png`,
      twitterCard: "summary_large_image",
    });

    useHead({
      link: [
        {
          rel: "canonical",
          href: seo?.page?.seo_canonical
            ? `${
                siteConfig.value.public.siteUrl
              }/${seo?.page?.seo_canonical.toLowerCase()}`
            : siteConfig.value.public.siteUrl.toLowerCase(),
        },
      ],
    });
  };

  const organizationSchema = () =>
    defineOrganization({
      name: "انارستان",
      alternateName: "Anaarestan",
      url: siteConfig.value.public.siteUrl,
      logo: `${siteConfig.value.public.siteUrl}/favicon.png`,
      contactPoint: {
        "@type": "ContactPoint",
        telephone: siteConfig.value.public.phones.mashhad,
        contactType: "sales",
        areaServed: "IR",
        availableLanguage: "Persian",
      },
      sameAs: [
        "https://www.facebook.com/anaarestan",
        "https://x.com/anaarestan",
        "https://www.instagram.com/anaarestan/",
        "https://www.youtube.com/@anaarestan",
      ],
    });

  const websiteSchema = () =>
    defineWebSite({
      url: siteConfig.value.public.siteUrl,
      name: siteConfig.value.public.siteNameFa,
      alternateName: siteConfig.value.public.siteNameEn,
      description:
        siteConfig.value?.public?.desc ||
        "انارستان یک فروشگاه آنلاین برای خرید کالاهای متنوع است؛ از خوراک و پوشاک گرفته تا اسباب‌بازی و لوازم خانه، با امکان بررسی محصولات و ثبت سفارش آنلاین.",
      publisher: {
        "@type": "Organization",
        name: "انارستان",
        url: siteConfig.value.public.siteUrl,
        logo: {
          "@type": "ImageObject",
          url: `${siteConfig.value.public.siteUrl}/images/logo.png`,
          width: "360",
          height: "100",
          caption: "لوگوی انارستان",
        },
      },
      inLanguage: "fa-IR",
    });

  const webpageSchema = (seo: PageResponse) =>
    defineWebPage({
      name: seo?.page?.title || "فروشگاه آنلاین خرید کالاهای متنوع",
      description:
        seo?.page?.seo_description ||
        siteConfig.value?.public?.desc ||
        "انارستان، فروشگاه آنلاین انواع محصولات",
      url: seo?.page?.seo_canonical || siteConfig.value.public.siteUrl,
      inLanguage: "fa-IR",
    });

  return { buildMeta, organizationSchema, websiteSchema, webpageSchema };
};
