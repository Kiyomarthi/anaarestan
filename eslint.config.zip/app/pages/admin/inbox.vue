<script setup lang="ts">
///// imports /////

///// page meta /////
definePageMeta({
  layout: "admin",
});
///// props/emits /////

///// refs /////

///// composables/stores /////

///// computed /////

///// watchers /////

///// functions /////

///// lifecycle /////
</script>

<template>
  <div>inbox</div>
</template>
