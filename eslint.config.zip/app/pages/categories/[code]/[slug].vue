<script setup lang="ts">
///// imports /////

///// page meta /////

///// props/emits /////

///// refs /////

///// composables/stores /////

///// computed /////

///// functions /////

///// watchers /////

///// lifecycle /////
</script>

<template>
  <div>
    code/slug category
  </div>
</template>
