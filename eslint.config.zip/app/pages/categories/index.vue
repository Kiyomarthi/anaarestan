<script setup lang="ts">
///// imports /////

///// page meta /////
definePageMeta({
  middleware: "desktop-only-client",
});

///// props/emits /////

///// refs /////

///// composables/stores /////

///// computed /////

///// watchers /////

///// functions /////

///// lifecycle /////
</script>

<template>
  <div>hello</div>
</template>
