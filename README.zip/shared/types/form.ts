export interface Error {
  name: string;
  message: string;
}
